function d = kernel_lin(a,b);
d=a*b';
