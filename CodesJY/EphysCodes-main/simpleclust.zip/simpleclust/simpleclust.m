% alias function, in case you forget the underscore!

simple_clust