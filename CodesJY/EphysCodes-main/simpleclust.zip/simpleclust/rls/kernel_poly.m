function d = kernel_gauss(a,b);
deg = 5;
d=(a*b'+1).^deg;